package com.example.trabbd.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.trabbd.CadastroActivity;
import com.example.trabbd.R;
import com.example.trabbd.db.DBHelperJogador;
import com.example.trabbd.db.DBHelperTime;
import com.example.trabbd.db.Jogador;
import com.example.trabbd.db.Times;

import java.util.ArrayList;


public class CadastroTimeFragment extends Fragment {

    private static String selectedItem;
    public ListView listTime;
    public ListView listTimesCad;
    public ListView listJogador;
    private EditText edtDescricao;
    private TextView edtID;
    private Button btnVariavel;
    View TimeFragment;

    Times time, altTime;

    ArrayList<Times> arrayListTime;
    ArrayList<Jogador> arrayListJogador;
    ArrayAdapter<Jogador> jogadorArrayAdapter;

    public CadastroTimeFragment() {
        // Required empty public constructor
    }


    public static CadastroTimeFragment newInstance() {
        CadastroTimeFragment fragment = new CadastroTimeFragment();


        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //listTime = getActivity().findViewById(R.id.listJogadores);
        //registerForContextMenu(listTime);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        TimeFragment = inflater.inflate(R.layout.fragment_cadastro_time, container, false);

        return TimeFragment;
    }

    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        Intent it = getActivity().getIntent();
        altTime = (Times) it.getSerializableExtra("chave_emprestimo");
        time = new Times();
        DBHelperTime helperTime = new DBHelperTime(getActivity());



        edtDescricao = getView().findViewById(R.id.textDescrição);
        edtID = (TextView) getView().findViewById(R.id.textEmpID);
        btnVariavel = getView().findViewById(R.id.buttonEmp);

        listJogador = (ListView) getView().findViewById(R.id.listJogadoresCad);
        registerForContextMenu(listJogador);
        DBHelperJogador helperJogador = new DBHelperJogador(getActivity());
        arrayListJogador = helperJogador.buscarJogadores();
        helperTime.close();
        if (listJogador != null) {
            jogadorArrayAdapter = new ArrayAdapter<Jogador>(getActivity(), android.R.layout.simple_list_item_1, arrayListJogador);
            listJogador.setAdapter(jogadorArrayAdapter);
        }
        listJogador.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                selectedItem = listJogador.getItemAtPosition(i).toString();

            }
        });

        if (altTime != null) {
            ((CadastroActivity)getActivity()).navigateFragment(0);
            btnVariavel.setText("Atualizar Time");
            edtDescricao.setText(altTime.getDescricao());
            int id = altTime.getIdTime();
            edtID.setText(String.valueOf(id));
            time.setIdTime(altTime.getIdTime());
        }
        else {
            btnVariavel.setText("Cadastrar Time!");
        }
    }

    public static String getSelectedItem() {
        return selectedItem;
    }

    public static void setSelectedItemNull(){
        selectedItem = null;
    }

}