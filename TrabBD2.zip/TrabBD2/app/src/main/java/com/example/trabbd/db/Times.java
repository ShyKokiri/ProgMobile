package com.example.trabbd.db;

import java.io.Serializable;

public class Times implements Serializable {

    private int idTime;
    private String descricao;


    public int getIdTime() {
        return idTime;
    }

    public void setIdTime(int idTime) {
        this.idTime = idTime;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }


    @Override
    public String toString() {
        return "Time{" +
                "idTime=" + idTime +
                ", descricao='" + descricao + '\'' +
                '}';
    }
}
