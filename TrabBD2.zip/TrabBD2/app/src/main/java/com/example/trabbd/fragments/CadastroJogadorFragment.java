package com.example.trabbd.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.trabbd.CadastroActivity;
import com.example.trabbd.R;
import com.example.trabbd.db.DBHelperJogador;
import com.example.trabbd.db.Jogador;


public class CadastroJogadorFragment extends Fragment {

    Jogador altJogador;
    private EditText edtNome, edtCpf;
    private Button btnVariavel;
    private TextView edtID;
    private Jogador jogador;

    public CadastroJogadorFragment() {
        // Required empty public constructor
    }

    public static CadastroJogadorFragment newInstance() {
        CadastroJogadorFragment fragment = new CadastroJogadorFragment();


        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_cadastro_jogador, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Intent it = getActivity().getIntent();

        altJogador = (Jogador) it.getSerializableExtra("chave_jogador");

        jogador = new Jogador();
        DBHelperJogador helperJogador = new DBHelperJogador(getActivity());

        edtNome = getView().findViewById(R.id.textPlayerName);
        edtCpf = getView().findViewById(R.id.textCPF);
        edtID = (TextView) getView().findViewById(R.id.textPlayerID);

        btnVariavel = getView().findViewById(R.id.buttonEquip);

        if (altJogador != null) {
            ((CadastroActivity)getActivity()).navigateFragment(1);
            btnVariavel.setText("Atualizar jogador");
            edtNome.setText(altJogador.getNome());
            edtCpf.setText(altJogador.getCpf());
            int id = altJogador.getId();
            edtID.setText(String.valueOf(id));
            jogador.setId(altJogador.getId());
        }
        else {
            btnVariavel.setText("Cadastrar jogador!");
        }
    }



    public void onResume(){
        super.onResume();
    }
}