package com.example.trabbd.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.trabbd.CadastroActivity;
import com.example.trabbd.MainActivity;
import com.example.trabbd.R;
import com.example.trabbd.db.DBHelperTime;
import com.example.trabbd.db.Times;

import java.util.ArrayList;

public class TimeFragment extends Fragment {
    private static String selectedItem;
    public ListView listTime;
    View fragmentoTime;
    Times time;
    private int id1, id2, id3;

    ArrayList<Times> arrayListTimes;
    ArrayAdapter<Times> timesArrayAdapter;


    public TimeFragment() {
        // Required empty public constructor
    }

    public static TimeFragment newInstance() {
        TimeFragment fragment = new TimeFragment();

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_time, container, false);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        listTime = (ListView) getView().findViewById(R.id.listTimes);
        registerForContextMenu(listTime);
        DBHelperTime helperTime = new DBHelperTime(getActivity());
        arrayListTimes= helperTime.buscarTimes();
        helperTime.close();
        if (listTime != null) {
            timesArrayAdapter = new ArrayAdapter<Times>(getActivity(), android.R.layout.simple_list_item_1, arrayListTimes);
            listTime.setAdapter(timesArrayAdapter);
        }
        listTime.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                Times timeEnviado = (Times) timesArrayAdapter.getItem(position);
                Intent it = new Intent(getActivity(), CadastroActivity.class);
                it.putExtra("chave_time", timeEnviado);
                startActivity(it);

            }
        });

        listTime.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long id) {
                time = timesArrayAdapter.getItem(position);
                return false;
            }
        });

    }
   @Override
   public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {

        MenuItem mDelete = menu.add(Menu.NONE, id2, 1, "Apague time");
        MenuItem mSair = menu.add(Menu.NONE, id3, 2, "Cancela");
        mDelete.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
           public boolean onMenuItemClick(MenuItem menuItem) {
                long retornoBD;
                DBHelperTime helperTime = new DBHelperTime(getActivity());
                retornoBD = helperTime.excluirTime(time);
                helperTime.close();
                if (retornoBD == -1) {
                    alert("Erro de exclusão!");
                } else {
                    alert("Registro excluído com sucesso!");
//                    ((MainActivity) getActivity()).navigateFragment(1);
                    reloadActivity(v);
                }
                return false;
            }
        });

       super.onCreateContextMenu(menu, v, menuInfo);
    }

       private void alert(String s) {
           Toast.makeText(getActivity(), s, Toast.LENGTH_LONG).show();
       }
       public void reloadActivity(View view) {
           Intent intent = new Intent(getActivity(), MainActivity.class);
           getActivity().finish();
           startActivity(intent);
       }

    public static String getSelectedItem() {
        return selectedItem;
    }
}