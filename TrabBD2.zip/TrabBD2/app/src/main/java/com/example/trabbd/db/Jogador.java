package com.example.trabbd.db;

import java.io.Serializable;

public class Jogador implements Serializable {
    private String nome, cpf;
    private int id;
    private int idTime;
    private String AnoNascimento;
    boolean existe;


    public boolean isExiste() {
        return existe;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public String getAnoNascimento() {
        return AnoNascimento;
    }

    public void setAnoNascimento(String anoNascimento) {
        this.AnoNascimento = anoNascimento;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public int getIdTime() {
        return idTime;
    }

    public void setIdTime(int idTime) {
        this.idTime = idTime;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Jogador{" +
                "nome='" + nome + '\'' +
                ", cpf='" + cpf + '\'' +
                ", id=" + id +
                ", idTime=" + idTime +
                ", AnoNascimento=" + AnoNascimento +
                '}';
    }
}
