package com.example.trabbd;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.example.trabbd.databinding.ActivityCadastroBinding;
import com.example.trabbd.db.DBHelperJogador;
import com.example.trabbd.db.DBHelperTime;
import com.example.trabbd.db.Jogador;
import com.example.trabbd.db.Times;
import com.example.trabbd.fragments.CadastroTimeFragment;
import com.example.trabbd.ui.main.CadastroSectionsPagerAdapter;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;

public class CadastroActivity extends AppCompatActivity {

    private ViewPager viewPager;

    private ActivityCadastroBinding binding;
    private DBHelperJogador helperJogador = new DBHelperJogador(this);
    private DBHelperTime helperTime= new DBHelperTime(this);

    private EditText edtNome;
    private EditText edtCpf;
    private EditText edtAnoNascimento;
    private TextView edtID;
    private Button btnVariavel;

    private ListView listJogador;

    ArrayList<Jogador> arrayListJogador;
    ArrayAdapter<Jogador> jogadorArrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCadastroBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        CadastroSectionsPagerAdapter sectionsPagerAdapter = new CadastroSectionsPagerAdapter(this, getSupportFragmentManager());
        viewPager = binding.viewPager;
        viewPager.setAdapter(sectionsPagerAdapter);
        TabLayout tabs = binding.tabs;
        tabs.setupWithViewPager(viewPager);


    }

    public void onResume() {
        super.onResume();
    }


    public void efetuarTime(View view) {
        edtNome = findViewById(R.id.textPersonName);
        edtCpf = findViewById(R.id.textCPF);
        String descricao = edtNome.getText().toString();
        String CPF = edtCpf.getText().toString();
        String selectedItem = CadastroTimeFragment.getSelectedItem();
        CadastroTimeFragment.setSelectedItemNull();
        btnVariavel = findViewById(R.id.buttonEmp);

        if (!descricao.equals("") && !CPF.equals("") && selectedItem != null) {
            String jogadorIDStr = selectedItem.substring(selectedItem.indexOf("ID: ") + 4);
            int jogadorID = Integer.parseInt(jogadorIDStr);

            Times t = new Times();
            t.setDescricao(descricao);
            t.setIdTime(jogadorID);

            if (btnVariavel.getText().toString().equals("Cadastrar Time!")) {

                helperTime.insereTime(t);
                Snackbar.make(view, "Time cadastrado!", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
                reloadActivity(view);
            } else {
                edtID = (TextView) findViewById(R.id.textEmpID);
                int id = Integer.parseInt(edtID.getText().toString());

                t.setIdTime(id);
                helperTime.atualizarTime(t);
                Snackbar.make(view, "Time atualizado!", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
                reloadActivity(view);
            }
        } else {
            Snackbar.make(view, "Preencha os campos corretamente", Snackbar.LENGTH_LONG)
                    .setAction("Action", null).show();
        }
    }

    public void cadastrarJogador(View view) {
        edtNome = findViewById(R.id.textPlayerName);
        edtCpf = findViewById(R.id.textCPF);
        String nome = edtNome.getText().toString();
        String cpf = edtCpf.getText().toString();
        String anoNascimento = edtAnoNascimento.getText().toString();
        btnVariavel = findViewById(R.id.buttonEquip);

        if (!nome.equals("") && !cpf.equals("")) {
            Jogador j = new Jogador();
            j.setNome(nome);
            j.setAnoNascimento(anoNascimento);
            j.setCpf(cpf);
            if (btnVariavel.getText().toString().equals("Cadastrar jogador!")) {
                helperJogador.insereJogador(j);
                Snackbar.make(view, "Jogador Cadastrado!", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
                reloadActivity(view);
            } else {
                edtID = (TextView) findViewById(R.id.textPlayerID);
                int id = Integer.parseInt(edtID.getText().toString());

                j.setId(id);
                helperJogador.atualizarJogador(j);
                Snackbar.make(view, "Jogador atualizado!", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
                reloadActivity(view);

            }
        } else {
            Snackbar.make(view, "Preencha os campos corretamente", Snackbar.LENGTH_LONG)
                    .setAction("Action", null).show();
        }
        helperJogador.close();

    }

    public void navigateFragment(int position) {
        viewPager.setCurrentItem(position, true);
    }

    public void reloadActivity(View view) {
        Intent intent = new Intent(CadastroActivity.this, MainActivity.class);
        finish();
        startActivity(intent);
    }
}