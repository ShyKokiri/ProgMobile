package com.example.trabbd.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class DBHelperJogador extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 2;
    private static final String DATABASE_NAME_1= "jogador.db";
    private static final String TABLE_JOGADOR = "jogador";
    private static final String COL_ID = "id";
    private static final String COL_NOME = "nome";
    private static final String COL_IDTIME_FK = "idTime";
    private static final String COL_CPF = "cpf";
    private static final String COL_ANONASCIMENTO = "anoNascimento";

    private static final String DATABASE_NAME_2= "time.db";
    private static final String TABLE_TIME = "time";
    private static final String COL_IDTIME = "idTime";
    private static final String COL_DESCRICAO = "descricao";

    private static final String TABLE_CREATE="create table "+TABLE_TIME+
            "("+COL_IDTIME+" integer primary key autoincrement, "+
            COL_DESCRICAO+" text not null);";

    SQLiteDatabase db;

    private static final String TABLE_CREATE_2="create table "+TABLE_JOGADOR+
            "("+COL_ID+" integer primary key autoincrement, "+
            COL_NOME+" text not null, "+COL_IDTIME_FK+" integer, " +
            COL_CPF+" text not null, "+COL_ANONASCIMENTO+" integer, "+
            "FOREIGN KEY("+COL_IDTIME_FK+") REFERENCES "+TABLE_TIME+"("+COL_IDTIME+"));";

    public DBHelperJogador(@Nullable Context context) {

        super(context, DATABASE_NAME_1,null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_CREATE_2);
        this.db = db;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String query = "DROP TABLE IF EXISTS "+TABLE_JOGADOR;
        db.execSQL(query);
        this.onCreate(db);
    }

    public void insereJogador(Jogador j) {
        db = this.getWritableDatabase();
        db.beginTransaction();
        try {
            ContentValues values = new ContentValues();
            values.put(COL_NOME, j.getNome());
            values.put(COL_ID, j.getId());
            values.put(COL_IDTIME_FK, j.getIdTime());
            values.put(COL_CPF, j.getCpf());
            values.put(COL_ANONASCIMENTO, j.getAnoNascimento());
            db.insertOrThrow(TABLE_JOGADOR, null, values);
            db.setTransactionSuccessful();
        } catch (Exception e) {
            Log.d("TAG", "Erro ao inserir na tabela");
        } finally {
            db.endTransaction();
        }
    }

    public long excluirJogador(Jogador j){
        long retornoDB;
        db=this.getWritableDatabase();
        String[] args={String.valueOf(j.getId())};

        retornoDB=db.delete(TABLE_JOGADOR,COL_IDTIME_FK+"=?",args);
        return retornoDB;
    }

    public long atualizarJogador(Jogador j){
        long retornoDB;
        db=this.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put(COL_NOME,j.getNome());
        values.put(COL_CPF,j.getCpf());
        values.put(COL_ID,j.getId());
        values.put(COL_ANONASCIMENTO,j.getAnoNascimento());
        values.put(COL_IDTIME_FK,j.getIdTime());
        String[] args= {String.valueOf(j.getId())};
        retornoDB=db.update(TABLE_JOGADOR,values,"id=?",args);
        return retornoDB;
    }

    public ArrayList<Jogador> buscarJogadores(){
        String[] colunas={COL_ID,COL_NOME,COL_CPF,COL_ANONASCIMENTO,COL_IDTIME_FK};
        Cursor cursor = getReadableDatabase().query(TABLE_JOGADOR,colunas,null,
                null,null,null,"upper(nome)",null);
        ArrayList<Jogador> list = new ArrayList<Jogador>();
        while(cursor.moveToNext()){
            Jogador j = new Jogador();
            j.setNome(cursor.getString(0));
            j.setId(cursor.getInt(1));
            j.setCpf(cursor.getString(2));
            j.setAnoNascimento(cursor.getString(3));
            j.setIdTime(cursor.getInt(4));
            list.add(j);
        }
        return list;
    }
    

    public boolean jogadorExistsOnTime(int idTime) {
        db = this.getReadableDatabase();
        boolean jogadorExist = false;
        String[] columns = {COL_IDTIME_FK, COL_NOME, COL_ID, COL_CPF,COL_ANONASCIMENTO};
        String[] args = {String.valueOf(idTime)};
        Cursor cursor = getReadableDatabase().query(TABLE_JOGADOR, columns, "timeId=?", args, null, null, null, null);

        Jogador j = new Jogador();
        while(cursor.moveToNext()) {
            j.setNome(cursor.getString(0));
            j.setId(cursor.getInt(1));
            j.setIdTime(cursor.getInt(2));
            j.setAnoNascimento(cursor.getString(3));
            j.setCpf(cursor.getString(4));
            if (!j. isExiste())
                jogadorExist = true;
        }
        return jogadorExist;
    }
}