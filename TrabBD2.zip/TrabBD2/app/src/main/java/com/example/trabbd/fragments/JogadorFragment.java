package com.example.trabbd.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.trabbd.CadastroActivity;
import com.example.trabbd.MainActivity;
import com.example.trabbd.R;
import com.example.trabbd.db.DBHelperJogador;
import com.example.trabbd.db.Jogador;

import java.util.ArrayList;

public class JogadorFragment extends Fragment {

    private static String selectedItem;
    public ListView listJogadores;
    Jogador jogador;
    private int id1, id2;

    ArrayList<Jogador> arrayListJogador;
    ArrayAdapter<Jogador> jogadorArrayAdapter;

    public JogadorFragment() {
        // Required empty public constructor
    }

    public static JogadorFragment newInstance() {
        JogadorFragment fragment = new JogadorFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_jogador, container, false);
    }

    public void onResume() {
        super.onResume();
    }

    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        listJogadores = (ListView) getView().findViewById(R.id.listJogadoresCad);
        registerForContextMenu(listJogadores);
        DBHelperJogador helperJogador = new DBHelperJogador(getActivity());
        arrayListJogador = helperJogador.buscarJogadores();
        helperJogador.close();
        if (listJogadores != null) {
            jogadorArrayAdapter = new ArrayAdapter<Jogador>(getActivity(), android.R.layout.simple_list_item_1, arrayListJogador);
            listJogadores.setAdapter(jogadorArrayAdapter);
        }

        listJogadores.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                Jogador equipamentoEnviado = (Jogador) jogadorArrayAdapter.getItem(position);
                Intent it = new Intent(getActivity(), CadastroActivity.class);
                it.putExtra("chave_equipamento", equipamentoEnviado);
                startActivity(it);
            }
        });
        listJogadores.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long id) {
                jogador = jogadorArrayAdapter.getItem(position);
                return false;
            }
        });

    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        DBHelperJogador helperJogador = new DBHelperJogador(getActivity());

        int jogadorID = this.jogador.getId();
        boolean timeExist = helperJogador.jogadorExistsOnTime(jogadorID);
        if (!timeExist) {
           MenuItem mDelete = menu.add(Menu.NONE, id1, 1, "Apague jogador");
           MenuItem mSair = menu.add(Menu.NONE, id2, 2, "Cancela");
            mDelete.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
               @Override
                public boolean onMenuItemClick(MenuItem menuItem) {
                    long retornoBD;
                    DBHelperJogador helperEquipamento = new DBHelperJogador(getActivity());
                    retornoBD = helperEquipamento.excluirJogador(jogador);
                    helperEquipamento.close();
                    if (retornoBD == -1) {
                        alert("Erro de exclusão!");
                    } else {
                        alert("Registro excluído com sucesso!");
//                    ((MainActivity) getActivity()).navigateFragment(1);
                        reloadActivity(v);
                    }
                    return false;
                }
            });
        }
        else {
            MenuItem mSair = menu.add(Menu.NONE, id2, 1, "Cancela");
        }
        super.onCreateContextMenu(menu, v, menuInfo);
    }

    private void alert(String s) {
        Toast.makeText(getActivity(), s, Toast.LENGTH_LONG).show();
    }

    public void reloadActivity(View view) {
        Intent intent = new Intent(getActivity(), MainActivity.class);
        getActivity().finish();
        startActivity(intent);
    }
}