package com.example.trabbd.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class DBHelperTime extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 2;

    private static final String DATABASE_NAME_2= "time.db";
    private static final String TABLE_TIME = "time";
    private static final String COL_IDTIME = "idTime";
    private static final String COL_DESCRICAO = "descricao";

    private static final String TABLE_CREATE="create table "+TABLE_TIME+
            "("+COL_IDTIME+" integer primary key autoincrement, "+
            COL_DESCRICAO+" text not null);";


    SQLiteDatabase db;
    public DBHelperTime(@Nullable Context context) {

        super(context, DATABASE_NAME_2,null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_CREATE);
        this.db = db;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String query = "DROP TABLE IF EXISTS "+TABLE_TIME;
        db.execSQL(query);
        this.onCreate(db);
    }


        public void insereTime(Times t) {
            db = this.getWritableDatabase();
            db.beginTransaction();
            try {
                ContentValues values = new ContentValues();
                values.put(COL_IDTIME, t.getIdTime());
                values.put(COL_DESCRICAO, t.getDescricao());
                db.insertOrThrow(TABLE_TIME, null, values);
                db.setTransactionSuccessful();
            } catch (Exception e) {
                Log.d("TAG", "Erro ao inserir na tabela");
            } finally {
                db.endTransaction();
            }
        }


        public long excluirTime(Times t){
            long retornoDB;
            db=this.getWritableDatabase();
            String[] args={String.valueOf(t.getIdTime())};

            retornoDB=db.delete(TABLE_TIME,COL_IDTIME+"=?",args);
            return retornoDB;
        }


    public long atualizarTime(Times t){
        long retornoDB;
        db=this.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put(COL_DESCRICAO,t.getDescricao());
        String[] args= {String.valueOf(t.getIdTime())};
        retornoDB=db.update(TABLE_TIME,values,"id=?",args);
        return retornoDB;
        }


    public ArrayList<Times> buscarTimes(){
        String[] colunas={COL_IDTIME,COL_DESCRICAO};
        Cursor cursor = getReadableDatabase().query(TABLE_TIME,colunas,null,
                null,null,null,"upper(descricao)",null);
        ArrayList<Times> list = new ArrayList<Times>();
        while(cursor.moveToNext()){
            Times t = new Times();
            t.setIdTime(cursor.getInt(0));
            t.setDescricao(cursor.getString(1));
            list.add(t);
        }
        return list;
    }
}


